// Generate Nav bar A-Z
// const alphabetNav = document.getElementById('alphabetNav');
// const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
// for (const letter of alphabet) {
//     const li = document.createElement('li');
//     li.innerHTML = `<a href="#" onclick="filterByLetter('${letter}')">${letter}</a>`;
//     alphabetNav.appendChild(li);
// }

// let plantData = []; // To store plant data from Elasticsearch

// Fetch plant data from Elasticsearch API
// fetch('https://your-elasticsearch-endpoint/index/_search', {
//     method: 'POST',
//     headers: {
//         'Content-Type': 'application/json'
//     },
//     body: JSON.stringify({
//         query: {
//             match_all: {} // Example query: fetch all documents
//         }
//     })
// })
//     .then(response => response.json())
//     .then(esResponse => {
//         // Extract data from Elasticsearch hits
//         plantData = esResponse.hits.hits.map(hit => hit._source);

//         displayRandomPlants(); // Show random plants initially
//     });

const { Client } = require('@elastic/elasticsearch');
const fs = require('fs'); 
const path = require('path');

// Replace with your Elasticsearch instance URL
const client = new Client({ node: 'http://localhost:9200',auth: {
    username: 'elastic',  // Replace with your username
    password: 'Ppll-pZ10OMccb4CyZlE'   // Replace with your password
  },
  tls: {
    rejectUnauthorized: false,
    ca: fs.readFileSync(path.join(__dirname, 'http_ca.crt'))
  } });

// Test the connection
(async () => {
  try {
    const health = await client.cluster.health();
    console.log('Elasticsearch cluster health:', health);
  } catch (error) {
    console.error('Error connecting to Elasticsearch:', error);
  }
})();

// // Load plant data from the CSV
// fetch('100Plantdata.csv')
//     .then(response => response.text())
//     .then(csvText => {
//         Papa.parse(csvText, {
//             header: true,
//             skipEmptyLines: true,
//             complete: function (results) {
//                 plantData = results.data;
//                 displayRandomPlants(); // Show random plants initially
//             }
//         });
//     });

// Display random plants
// function displayRandomPlants() {
//     const resultsDiv = document.getElementById('results');
//     resultsDiv.innerHTML = ''; // Clear previous results

//     // Shuffle and select 24 random plants
//     const randomPlants = plantData.sort(() => 0.5 - Math.random()).slice(0, 24);

//     randomPlants.forEach(plant => {
//         const plantDiv = document.createElement('div');
//         plantDiv.classList.add('plant');
//         plantDiv.onclick = () => showPlantDetails(plant);

//         const imageHTML = plant.Image && plant.Image.toLowerCase().endsWith('.jpg') ?
//             `<img src="${plant.Image}" alt="${plant.Name}" style="width: 100%; height: 150px; object-fit: cover;">` : '';
//         plantDiv.innerHTML = `
//             ${imageHTML}
//             <div class="plant-info">
//                 <p><span class="label">Name:</span> ${plant['Plant Name'] || 'N/A'}</p>
//             </div>
//         `;
//         resultsDiv.appendChild(plantDiv);
//     });
// }

// // Search plants
// function searchPlants() {
//     const query = document.getElementById('search').value.toLowerCase();
//     const results = plantData.filter(plant =>
//         Object.values(plant).some(value => value && value.toLowerCase().includes(query))
//     );
//     displayPlants(results);
// }

// // Filter by letter
// function filterByLetter(letter) {
//     const results = plantData.filter(plant => 
//         plant['Plant Name'] && plant['Plant Name'].startsWith(letter)
//     );
//     displayPlants(results);
// }

// // Display plants dynamically
// function displayPlants(plants) {
//     const resultsDiv = document.getElementById('results');
//     resultsDiv.innerHTML = ''; // Clear previous results

//     plants.forEach(plant => {
//         const plantDiv = document.createElement('div');
//         plantDiv.classList.add('plant');
//         plantDiv.onclick = () => showPlantDetails(plant);

//         const imageHTML = plant.Image && plant.Image.toLowerCase().endsWith('.jpg') ?
//             `<img src="${plant.Image}" alt="${plant['Plant Name']}" style="width: 100%; height: 150px; object-fit: cover;">` : '';

//         plantDiv.innerHTML = `
//             ${imageHTML}
//             <div class="plant-info">
//                 <p><span class="label">Name:</span> ${plant['Plant Name'] || 'N/A'}</p>
//             </div>
//         `;
//         resultsDiv.appendChild(plantDiv);
//     });

//     if (plants.length === 0) {
//         resultsDiv.innerHTML = `<p>No plants found starting with "${letter}".</p>`;
//     }
// }

// // Show detailed plant information
// function showPlantDetails(plant) {
//     const detailsDiv = document.getElementById('plantDetails');
//     const imageHTML = plant.Image && plant.Image.toLowerCase().endsWith('.jpg') ?
//         `<img src="${plant.Image}" alt="${plant.Name}" style="width: 100%; height: auto; object-fit: cover;">` : '';

//     // Generate dynamic content for all columns
//     const plantContent = Object.keys(plant).map(key => {
//         const value = plant[key] && plant[key].trim() ? plant[key] : 'N/A';
//         return `<p><span class="label">${key}:</span> ${value}</p>`;
//     }).join('');

//     detailsDiv.innerHTML = `
//         ${imageHTML}
//         <div>
//             ${plantContent}
//         </div>
//     `;
// }

